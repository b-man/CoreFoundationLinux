Index: libcorefoundation-635/CFArray.c
===================================================================
--- libcorefoundation-635.orig/CFArray.c	2011-09-01 18:05:29.000000000 -0400
+++ libcorefoundation-635/CFArray.c	2011-09-01 18:05:38.000000000 -0400
@@ -30,7 +30,6 @@
 #include <CoreFoundation/CFPriv.h>
 #include "CFInternal.h"
 #include <string.h>
-#include <CoreFoundation/CFVersionCheck.h>
 
 const CFArrayCallBacks kCFTypeArrayCallBacks = {0, __CFTypeCollectionRetain, __CFTypeCollectionRelease, CFCopyDescription, CFEqual};
 static const CFArrayCallBacks __kCFNullArrayCallBacks = {0, NULL, NULL, NULL, NULL};
